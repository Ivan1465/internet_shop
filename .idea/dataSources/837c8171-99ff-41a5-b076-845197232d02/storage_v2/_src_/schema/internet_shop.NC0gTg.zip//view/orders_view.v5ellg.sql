create definer = root@localhost view orders_view as
select `o`.`id` AS `id`, `o`.`status_id` AS `status_id`, `s`.`name` AS `status_name`
from (`internet_shop`.`order` `o` left join `internet_shop`.`statuses` `s` on ((`o`.`status_id` = `s`.`id`)));

